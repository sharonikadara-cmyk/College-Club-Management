const clubs = [
  {id:1,name:"CodeCrafters",category:"Technology",emoji:"💻",color:"#eee9ff",description:"Build cool things, learn new tech and turn your ideas into real projects.",members:248},
  {id:2,name:"Canvas Collective",category:"Arts",emoji:"🎨",color:"#fff0e8",description:"A creative corner for artists, designers, photographers and makers.",members:126},
  {id:3,name:"Green Campus",category:"Environment",emoji:"🌱",color:"#e4f7ed",description:"Make our campus greener through sustainability drives and small actions.",members:184},
  {id:4,name:"The Spotlight",category:"Social",emoji:"🎤",color:"#ffe8f1",description:"Stage performances, music, theatre and unforgettable campus moments.",members:205},
  {id:5,name:"Future Founders",category:"Business",emoji:"🚀",color:"#e8f3ff",description:"Explore entrepreneurship, pitch ideas and learn from fellow innovators.",members:153},
  {id:6,name:"Pixel Society",category:"Technology",emoji:"🕹️",color:"#fff5d9",description:"For gamers, UI lovers and digital creators who enjoy experimenting.",members:97}
];
const events = [
  {day:"18",month:"OCT",title:"Hack the Campus",time:"10:00 AM – 4:00 PM",place:"Innovation Lab",tag:"Technology"},
  {day:"21",month:"OCT",title:"Creative Canvas Day",time:"11:30 AM – 2:00 PM",place:"Student Activity Hall",tag:"Arts"},
  {day:"24",month:"OCT",title:"Green Campus Drive",time:"8:30 AM – 10:30 AM",place:"Main Garden",tag:"Environment"},
  {day:"28",month:"OCT",title:"Open Mic Evening",time:"5:00 PM – 7:00 PM",place:"Amphitheatre",tag:"Social"}
];
const joined = new Set();
const clubGrid = document.getElementById("clubGrid");
const membershipList = document.getElementById("membershipList");
const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const toast = document.getElementById("toast");
let toastTimer;
function notify(message){
  toast.textContent = message; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(()=>toast.classList.remove("show"),2600);
}
function renderClubs(){
  const query = searchInput.value.trim().toLowerCase();
  const category = categoryFilter.value;
  const visible = clubs.filter(c => (category === "all" || c.category === category) &&
    (c.name.toLowerCase().includes(query) || c.category.toLowerCase().includes(query) || c.description.toLowerCase().includes(query)));
  clubGrid.innerHTML = visible.map(c => `
    <article class="club-card">
      <div class="club-top"><span class="club-emoji" style="background:${c.color}">${c.emoji}</span><span class="club-category">${c.category}</span></div>
      <h3>${escapeHTML(c.name)}</h3><p>${escapeHTML(c.description)}</p>
      <div class="club-bottom"><span class="member-count">♙ ${(c.members + (joined.has(c.id)?1:0)).toLocaleString()} members</span>
      <button class="join-btn ${joined.has(c.id)?"joined":""}" data-join="${c.id}">${joined.has(c.id)?"✓ Joined":"＋ Join club"}</button></div>
    </article>`).join("");
  document.getElementById("emptyMessage").hidden = visible.length > 0;
  document.getElementById("clubCount").textContent = String(clubs.length).padStart(2,"0");
  renderMemberships();
}
function renderMemberships(){
  const mine = clubs.filter(c=>joined.has(c.id));
  if(!mine.length){
    membershipList.innerHTML='<p class="empty-message">You haven’t joined a club yet. Explore above and find your community!</p>';
    return;
  }
  membershipList.innerHTML = mine.map(c=>`<div class="member-chip"><span class="club-emoji" style="background:${c.color}">${c.emoji}</span><div><strong>${escapeHTML(c.name)}</strong><small>${c.category} · Member</small></div></div>`).join("");
}
function escapeHTML(value){
  return String(value).replace(/[&<>"']/g, ch=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
clubGrid.addEventListener("click", e=>{
  const button=e.target.closest("[data-join]"); if(!button)return;
  const id=Number(button.dataset.join); const club=clubs.find(c=>c.id===id);
  if(joined.has(id)){joined.delete(id);notify(`You left ${club.name}.`);}
  else{joined.add(id);notify(`You're in! Welcome to ${club.name}.`);}
  renderClubs();
});
searchInput.addEventListener("input",renderClubs);
categoryFilter.addEventListener("change",renderClubs);
document.getElementById("eventList").innerHTML=events.map(e=>`
  <article class="event-item"><div class="event-date"><strong>${e.day}</strong><small>${e.month}</small></div>
  <div class="event-info"><h3>${e.title}</h3><p>◷ ${e.time}<br>⌖ ${e.place}</p><div class="event-tag">${e.tag}</div></div></article>`).join("");
document.getElementById("eventCount").textContent=String(events.length).padStart(2,"0");
const dialog=document.getElementById("clubDialog");
document.getElementById("newClubBtn").addEventListener("click",()=>dialog.showModal());
document.getElementById("closeDialog").addEventListener("click",()=>dialog.close());
document.getElementById("clubForm").addEventListener("submit",e=>{
  e.preventDefault();
  const form=e.currentTarget; const data=new FormData(form);
  const name=String(data.get("name")).trim(), description=String(data.get("description")).trim(), category=String(data.get("category"));
  if(!name||!description)return;
  if(clubs.some(c=>c.name.toLowerCase()===name.toLowerCase())){notify("A club with that name already exists.");return;}
  const styles={Technology:["💻","#eee9ff"],Arts:["🎨","#fff0e8"],Social:["🎤","#ffe8f1"],Business:["🚀","#e8f3ff"],Environment:["🌱","#e4f7ed"]};
  const style=styles[category]||["✦","#eee9ff"];
  clubs.unshift({id:Date.now(),name,category,emoji:style[0],color:style[1],description,members:1});
  form.reset();dialog.close();renderClubs();notify(`${name} was created successfully!`);
});
renderClubs();
