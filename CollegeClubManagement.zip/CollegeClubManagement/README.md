# CampusConnect — College Club Management

A responsive front-end prototype for a college club management system. It helps students discover clubs, join or leave memberships, view upcoming events, search/filter clubs, and create a new club.

## Run the website

1. Download and extract the project folder.
2. Open `index.html` in a modern browser.

No package installation is required for this static demo.

## Main features

- Responsive campus dashboard
- Club cards with categories and member counts
- Search clubs by name, category, or description
- Filter clubs by category
- Join and leave clubs
- Create a club using the form
- Upcoming campus event list
- Membership section updates as you join clubs

## Project files

- `index.html` — page structure
- `style.css` — layout, colors, responsive styling
- `script.js` — demo data and interactive features

## Important implementation note

This version is a front-end prototype built with HTML, CSS, and JavaScript. The original problem statement asks for a MERN stack solution. To complete the full MERN version, add a React frontend, an Express/Node.js API, MongoDB models, and authentication/role-based access. The current prototype stores membership changes only in browser memory, so they reset when the page is refreshed.

## Suggested future backend collections

- `students`
- `clubs`
- `memberships`
- `events`
- `activities`

## Suggested REST API routes

- `GET /api/clubs`
- `POST /api/clubs`
- `GET /api/clubs/:id`
- `PUT /api/clubs/:id`
- `DELETE /api/clubs/:id`
- `POST /api/clubs/:id/join`
- `GET /api/events`
